import scrapy

class SpideroneItem(scrapy.Item):
     author = scrapy.Field()
     content = scrapy.Field()

class SpiderTwoItem(scrapy.Item):
     author = scrapy.Field()
     name = scrapy.Field()
     content = scrapy.Field()

class SpiderThreeItem(scrapy.Item):
     ip = scrapy.Field()
     port = scrapy.Field()

class ypicItem(scrapy.Item):
     url = scrapy.Field()

class IPProxyItem(scrapy.Item):
     ip = scrapy.Field()
     port = scrapy.Field()

