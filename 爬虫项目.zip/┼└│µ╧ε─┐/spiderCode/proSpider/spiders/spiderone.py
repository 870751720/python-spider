'''+
本爬虫是爬取糗事百科的标题和作者
知识点:
xpath的使用,普通爬虫的使用
'''
import scrapy
from proSpider.items import SpideroneItem

class SpideroneSpider(scrapy.Spider):
    name = 'spiderone'
    allowed_domains = ['qiushibaike.com']
    start_urls = ['http://qiushibaike.com/text/page/1/']
    base_domain = "http://qiushibaike.com"
    def parse(self, response):
        duanzidivs = response.xpath("//div[@id='content-left']/div")
        for duanzidiv in duanzidivs:
            author = duanzidiv.xpath(".//h2/text()").get().strip()
            content = duanzidiv.xpath(".//div[@class='content']//text()").getall()
            content = "".join(content).strip()
            item = SpideroneItem(author = author,content = content)
            print("爬到:author" + author)
            yield item
        nextUrl = response.xpath("//ul[@class='pagination']/li[last()]/a/@href").get()
        if not nextUrl:
            return
        else:
            yield scrapy.Request(self.base_domain + nextUrl,callback = self.parse)
