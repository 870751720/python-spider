# -*- coding: utf-8 -*-
import scrapy
import json
import os
from proSpider.items import IPProxyItem

class IptestSpider(scrapy.Spider):
    name = 'iptest'
    allowed_domains = ['httpbin.org']
    start_urls = ['http://httpbin.org/']
    
    def start_requests(self):      
        self.base_url='http://www.httpbin.org/ip'
        try:
            fp = open('..\download\ipandport.json',"r")  
            content = fp.read()
            fp.close()
            content = "[" + content.replace("}", "},")[0:-1] + "]"
            self.ips = json.loads(content)
        except:
            pass
        else:
            yield scrapy.Request(url=self.base_url, callback=self.selfipparse,dont_filter = True)
        
    def parse(self, response):
        if response.text[15:].split(",", 1)[0] != self.myip:
            ip = response.meta['proxy'][7:].split(":", 1)[0]
            port = response.meta['proxy'][7:].split(":", 1)[1]
            item = IPProxyItem(ip = ip,port = port)
            print("ip校验成功一个")
            yield item
    def selfipparse(self, response):
        self.myip = response.text[15:].split(",", 1)[0]
        for num in range(0,len(self.ips) - 1): 
            ip = self.ips[num]['ip']
            port = self.ips[num]['port']
            proxy = 'http://' + str(ip) + ':' + str(port)
            print("第" + str(num + 1) + "个ip正在校验")
            yield scrapy.Request(url=self.base_url, callback=self.parse, meta={'proxy': proxy},dont_filter = True)