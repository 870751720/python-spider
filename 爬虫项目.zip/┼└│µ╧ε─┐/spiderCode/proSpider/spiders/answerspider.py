'''+
逆水寒答题
实现get带参数,cmd字体颜色更改
'''
import scrapy
import json
from urllib.parse import urlencode
import os
import ctypes,sys
class AnswerspiderSpider(scrapy.Spider):
    name = 'answerspider'
    allowed_domains = ['tapi.gfun.me']
    start_urls = ['http://tapi.gfun.me/nsh/kj/']
    data = {
        'callback':'jQuery17201439872877330064_1564984382977',
        'text':'',
        'perpage':'10',
        '_':'1564984402112'
    }
    def start_requests(self):      
        url = self.urlset()
        yield scrapy.Request(url= url,callback=self.parse)
        
    def parse(self, response):
        answers = json.loads(response.text[41:-2],encoding = 'utf8')
        for i in range(0,len(answers)):
            print(answers[i]['question'] + '\n')
            ChangePrint.newprint(answers[i]['answer'] + '\n') 
        input("")
        i=os.system('cls')
        url = self.urlset()
        yield scrapy.Request(url= url,callback=self.parse)

    def urlset(self):
        base_url='http://tapi.gfun.me/nsh/kj/api.php?'
        text = str(input("输入要查询的试题关键字:\n"))
        self.data['text'] = text
        params = urlencode(self.data)
        url =  base_url + params
        return url

class ChangePrint:

    def newprint(mess):
        handle = ctypes.windll.kernel32.GetStdHandle(-11)
        ctypes.windll.kernel32.SetConsoleTextAttribute(handle, 0x0a)
        sys.stdout.write(mess)
        ctypes.windll.kernel32.SetConsoleTextAttribute(handle, 0x09 | 0x0a | 0x0c)