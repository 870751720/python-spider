'''+
本爬虫是爬取快代理的免费代理ip和端口
知识点:
xpath的使用,普通爬虫的使用
'''
import scrapy
import time
from proSpider.items import SpiderThreeItem

class SpiderthreeSpider(scrapy.Spider):
    name = 'spiderthree'
    allowed_domains = ['www.kuaidaili.com']
    start_urls = ['https://www.kuaidaili.com/free/']

    def start_requests(self):      
        self.base_url='https://www.kuaidaili.com/free/inha/'
        yield scrapy.Request(url=self.base_url,callback=self.getpagenum)
    def getpagenum(self,response):
        pagenum = (response.xpath("//div[@id='listnav']//ul//li//a")[-1]).xpath("./text()").get()       
        for page in range(1,int(pagenum)):
            url=self.base_url+str(page)+'/'
            time.sleep(1)
            print("开始爬第" + str(page) + "页数据\n")
            yield scrapy.Request(url=url,callback=self.parse)
        pass
    def parse(self, response):
        ip = response.xpath('//td[@data-title="IP"]/text()').getall()        
        port = response.xpath('//td[@data-title="PORT"]/text()').getall()
        for i in range(0,len(ip)-1):
            item = SpiderThreeItem(ip = ip[i],port = port[i])
            yield item
        