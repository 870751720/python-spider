'''+
本爬虫是爬取微信开发者论坛的标题和作者
知识点:
rule选取可用链接,Crawl爬虫的使用
'''
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from proSpider.items import SpiderTwoItem
import json

class SpidertwoSpider(CrawlSpider):
    name = 'spidertwo'
    allowed_domains = ['developers.weixin.qq.com']
    start_urls = ['http://developers.weixin.qq.com/']

    rules = (
        Rule(LinkExtractor(allow=r'.+community/develop/mixflow?page=\d&tag=#post-list'), follow=True),
        Rule(LinkExtractor(allow=r'.+community/develop/doc/.+'), follow=False,callback = 'parse_item'),
    )

    def parse_item(self, response):
        name = response.xpath('//span[@class="post_title_content"]/text()').get()
        authorif = response.xpath('//div[@itemprop="author"]')
        author = authorif.xpath('.//meta[@itemprop="name"]/@content').get()
        content = response.xpath('//div[@class="ask_content"]//text()').getall()
        item = SpiderTwoItem(author = author,content = content,name = name)
        print("爬到:author" + author)
        yield item