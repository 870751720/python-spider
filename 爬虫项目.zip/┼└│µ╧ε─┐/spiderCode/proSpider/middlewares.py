'''+
有代理,申请头,Selenium使用例子
'''
from scrapy import signals
import random
from selenium import webdriver
import time
from scrapy.http.response.html import HtmlResponse

class UserAgentDownloadMiddleware(object):
    USERAGENTS = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML like Gecko) Chrome/44.0.2403.155 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.1 Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2226.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.4; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2224.3 Safari/537.36', 
        ]
    def process_request(self,request,spider):
        userAgent = random.choice(self.USERAGENTS)
        request.headers['User-Agent'] = userAgent

class IPProxyDownloadMiddleware(object):
    PROXIES = [       
        ]
    def process_request(self,request,spider):
        proxy = random.choice(self.PROXIES)
        request.meta['proxy'] = proxy
    def process_response(self,request,response,spider):
        pass 

class SeleniumDownloadMiddleware(object):
    def __init__(self):
        self.browser = webdriver.PhantomJS()
    def process_request(self,request,spider):
        self.browser.get(request.url)
        time.sleep(3)
        try:
            while True:
                showMore = self.driver.find_element_by_class_name('show-more')
                showMore.click()
                time.sleep(1)
                if not showMore:
                    break
                print("!!!!!!!!!!!!!!!!!")
        except:
            pass
        source = self.browser.page_source
        resopnse = HtmlResponse(url = self.browser.current_url,body = source ,request = request,encoding = 'utf-8')
        return resopnse
    