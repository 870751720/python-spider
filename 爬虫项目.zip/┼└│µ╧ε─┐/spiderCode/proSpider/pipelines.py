import json
import pymysql
import os
import proSpider.items
from scrapy.exporters import JsonLinesItemExporter
from twisted.enterprise import adbapi
from pymysql import cursors
from urllib import request

class ProspiderPipeline(object):
#-----------------------------------初始化----------------------------------------------
    def __init__(self):
        self.path = os.path.join(os.path.dirname(os.path.dirname(__file__)),'..\download')
        if not os.path.exists(self.path):
            os.mkdir(self.path)
#-----------------------------------判断进入哪一个爬虫的解析------------------------------
    def process_item(self, item, spider):
        if type(item) == proSpider.items.SpideroneItem:
            self.spideroned(item)
        elif type(item) == proSpider.items.SpiderTwoItem:
            self.spidertwod(item)
        elif type(item) == proSpider.items.SpiderThreeItem:
            self.spiderthreed(item)
        elif type(item) == proSpider.items.IPProxyItem:
            self.iptestd(item)
        elif type(item) == proSpider.items.ypicItem:
            self.ypicdownloadd(item)
        return item
#-------------------------------爬虫结束------------------------------------------------
    def close_spider(self,spider):
        try :
            self.fpone
        except :
            pass
        else : 
            self.fpone.close()
        try :
            self.fptwo
        except :
            pass
        else : 
            self.fptwo.close()
        try :
            self.fpthree
        except :
            pass
        else : 
            self.fpfour.close()
        try :
            self.fpfour
        except :
            pass
        else : 
            self.fpfour.close()
#-----------------------------第一个爬虫的操作-------------------------------------------
    def spideroned(self,item):
        try :
            self.fpone 
        except :
            self.fpone = open(self.path +"\qiushibaike.json",'wb')
            self.exporterone = JsonLinesItemExporter(self.fpone,ensure_ascii = False,encoding = 'utf8')
        self.exporterone.export_item(item)
#-----------------------------第二个爬虫的操作-------------------------------------------
    def spidertwod(self,item):
        try :
            self.fptwo
        except :
            self.fptwo = open(self.path +"\developers.json",'wb')
            self.exportertwo = JsonLinesItemExporter(self.fptwo,ensure_ascii = False,encoding = 'utf8')
        self.exportertwo.export_item(item)
#-----------------------------第三个爬虫的操作-------------------------------------------
    def spiderthreed(self,item):
        try :
            self.fpthree
        except :
            self.fpthree = open(self.path +"\ipandport.json",'wb')
            self.exporterthree = JsonLinesItemExporter(self.fpthree,ensure_ascii = False,encoding = 'utf8')
            self.exporterthree.export_item(item)
        self.exporterthree.export_item(item)
#-----------------------------iptest的操作-------------------------------------------
    def iptestd(self,item):
        try :
            self.fpfour
        except :
            self.fpfour = open(self.path +"\ipcanuse.json",'wb')
            self.exporterfour = JsonLinesItemExporter(self.fpfour,ensure_ascii = False,encoding = 'utf8')
            self.exporterfour.export_item(item)
        self.exporterfour.export_item(item)
#------------------------------下载Y图片爬虫的操作---------------------------------------
    def ypicdownloadd(self,item):
        url = item['url']
        filepath = self.path + "\yimages" +'\\' + str(url)[27:]
        if not os.path.exists(self.path + "\yimages"):
            os.mkdir(self.path + "\yimages")
        if os.path.exists(filepath):
            print("存在" + filepath)
        else :
            request.urlretrieve(url,filepath)
#------------------------------数据库操作爬虫的操作--------------------------------------
    def basedataspiderd(self,item):
        try:
            self.dbpool
        except :
            dbparams = {
                'host':'123.207.169.89',
                'port':3306,
                'user':'root',
                'password':'h74185296300.',
                'database':'jianshu',
                'charset':'utf8',
                'cursorclass':cursors.DictCursor
            }
            self.dbpool =adbapi.ConnectionPool('pymysql',**dbparams)
            self._sql = None
        defer = self.dbpool.runInteraction(self.insert_item,item)
        defer.addErrback(self.handle_error,item,spider)
    def insert_item(self,cursor,item):
        cursor.execute(self.sql,(item['name'],item['title']))
        pass
    def handle_error(self,error,item,spider):
        print('*'*20+"error")
        print(error)
        print('*'*20+"error")
        pass
    @property
    def sql(self):
        if not self._sql:
            self._sql = """
            insert into information(id,name,title) values(null,%s,%s)
            """
            return self._sql
        return self._sql   