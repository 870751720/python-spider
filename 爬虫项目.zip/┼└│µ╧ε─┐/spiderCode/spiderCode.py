﻿import urllib
import scrapy.spiderloader
import scrapy.statscollectors
import scrapy.logformatter
import scrapy.dupefilters
import scrapy.squeues
 
import scrapy.extensions.spiderstate
import scrapy.extensions.corestats
import scrapy.extensions.telnet
import scrapy.extensions.logstats
import scrapy.extensions.memusage
import scrapy.extensions.memdebug
import scrapy.extensions.feedexport
import scrapy.extensions.closespider
import scrapy.extensions.debug
import scrapy.extensions.httpcache
import scrapy.extensions.statsmailer
import scrapy.extensions.throttle
 
import scrapy.core.scheduler
import scrapy.core.engine
import scrapy.core.scraper
import scrapy.core.spidermw
import scrapy.core.downloader

import scrapy.downloadermiddlewares.stats
import scrapy.downloadermiddlewares.httpcache
import scrapy.downloadermiddlewares.cookies
import scrapy.downloadermiddlewares.useragent
import scrapy.downloadermiddlewares.httpproxy
import scrapy.downloadermiddlewares.ajaxcrawl
import scrapy.downloadermiddlewares.decompression
import scrapy.downloadermiddlewares.defaultheaders
import scrapy.downloadermiddlewares.downloadtimeout
import scrapy.downloadermiddlewares.httpauth
import scrapy.downloadermiddlewares.httpcompression
import scrapy.downloadermiddlewares.redirect
import scrapy.downloadermiddlewares.retry
import scrapy.downloadermiddlewares.robotstxt
 
import scrapy.spidermiddlewares.depth
import scrapy.spidermiddlewares.httperror
import scrapy.spidermiddlewares.offsite
import scrapy.spidermiddlewares.referer
import scrapy.spidermiddlewares.urllength
 
import scrapy.pipelines
 
import scrapy.core.downloader.handlers.http
import scrapy.core.downloader.contextfactory
import scrapy.core.downloader.handlers.datauri
import scrapy.core.downloader.handlers.file
import scrapy.core.downloader.handlers.s3
import scrapy.core.downloader.handlers.ftp
#-------------------py中用到的-------------------------------------------------------------------

import os
import re
import time
import json
import ctypes,sys
import random
import scrapy
import pymysql
from scrapy.exporters import JsonLinesItemExporter
from twisted.enterprise import adbapi
from pymysql import cursors
from urllib import request
from scrapy import signals
from selenium import webdriver
from urllib.parse import urlencode
from scrapy.spiders import CrawlSpider, Rule
from scrapy.http.response.html import HtmlResponse
from scrapy.linkextractors import LinkExtractor

#--------------------------------------主代码区---------------------------------------------------
import yagmail
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
way = int(input("要做什么事情?1 运行爬虫 2 运行邮件发送\n"))

if way == 1:
    spidername = str(input("输入运行爬虫名称:\n"))
    process = CrawlerProcess(get_project_settings())
    try:
        process.crawl(spidername)
        process.start()
        input()
    except:
        pass
elif way == 2:
    yag = yagmail.SMTP(user = "870751720@qq.com",password = "",host = "smtp.qq.com")
    subject = str(input("输入标题:\n"))
    content = str(input("输入内容:\n"))
    address = str(input("输入对方邮箱:\n"))
    contents = [content]
    yag.send(address,subject,contents)
    input()
else :
    print("输入错误")
    input()